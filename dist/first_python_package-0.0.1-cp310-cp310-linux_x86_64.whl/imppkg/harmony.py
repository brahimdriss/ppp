import sys
from imppkg.harmonic_mean import harmonic_mean

def main():
    try : 
        values = [float(i) for i in sys.argv[1:]]
        result = harmonic_mean(values)
        print(result)
    except:
        print("Incorrect values")
main()