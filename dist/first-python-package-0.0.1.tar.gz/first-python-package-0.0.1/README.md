# first-python-package
This package does amazing things.
## Installation
```shell
$ python -m pip install first-python-package
```